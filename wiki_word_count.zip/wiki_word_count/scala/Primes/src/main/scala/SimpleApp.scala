/* SimpleApp.scala */
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object SimpleApp {
  def main(args: Array[String]) {
val conf = new SparkConf().setAppName("SimpleApp")
val sc = new SparkContext(conf)

var prime = "prime"

//val textFile = sc.textFile("/inputs/numbers.txt")
val textFile = sc.textFile("/prime_input/prime_input1.txt")
//val counts = textFile.flatMap(line => line.split(" ")).map(word => (word, 1)).reduceByKey(_ + _)
val counts = textFile.flatMap(line => line.split(" ")).map(word=>(prime, isPrimeInt(word.toInt))).reduceByKey(_ + _)

counts.saveAsTextFile("/spark_prime_10to10_ver1")
  }

def isPrime(n: Int): Boolean = (2 to math.sqrt(n).toInt) forall (x => n % x != 0)
def isPrimeInt(n: Int): Int={
if(isPrime(n))
 return 1
else
 return 0
}

}
