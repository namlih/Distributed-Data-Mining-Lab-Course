/* SimpleApp.scala */
import scala.annotation.tailrec
import scala.collection.immutable.TreeSet
import scala.compat.Platform
import scala.io.Source

object SimpleApp extends App{
  def main(args: Array[String]) {
  val oeisPrimes = TreeSet(oeisPrimesText.map(_.toInt): _*)

  def rawText = Source.fromURL("https://oeis.org/A000040/a000040.txt")

  def oeisPrimesText = rawText.getLines.takeWhile(_.nonEmpty).map(_.split(" ")(1)).toList

  def isPrime(n: Long) = {
    val end = math.sqrt(n).toInt

    @tailrec
    def inner(d: Int): Boolean = {
      if (d > end) true
      else if (n % d != 0 && n % (d + 2) != 0) inner(d + 6) else false
    }

    n > 1 && ((n & 1) != 0 || n == 2) && (n % 3 != 0 || n == 3) && inner(5)
  }

  println(s"Found ${oeisPrimes.size} primes on OEIS , last is ${oeisPrimes.last}.")
  for (i <- (0 to oeisPrimes.last).par)
    assert(isPrime(i) == oeisPrimes.contains(i), s"Wrong $i")

  }
}
