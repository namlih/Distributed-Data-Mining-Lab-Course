val textFile = sc.textFile("/inputs/wiki.txt")
val counts = textFile.flatMap(line => line.split(" ")).map(word => (word, 1)).reduceByKey(_ + _)
val mostCommon = counts.map(p => (p._2, p._1)).sortByKey(false, 1)

val top125 = mostCommon.take(125)
sc.parallelize(top125).saveAsTextFile("/spark_top125_ver3")
