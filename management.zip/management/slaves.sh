scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@group2worker1.dyn.mwn.de:/home/hadoop/hadoop/etc/hadoop/slaves
scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@group2worker2.dyn.mwn.de:/home/hadoop/hadoop/etc/hadoop/slaves
scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@group2worker3.dyn.mwn.de:/home/hadoop/hadoop/etc/hadoop/slaves
scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@group2worker5.dyn.mwn.de:/home/hadoop/hadoop/etc/hadoop/slaves
scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@group2worker6.dyn.mwn.de:/home/hadoop/hadoop/etc/hadoop//slaves
scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@worker7:/home/hadoop/hadoop/etc/hadoop/slaves
scp /home/hadoop/hadoop/etc/hadoop/slaves hadoop@worker8:/home/hadoop/hadoop/etc/hadoop/slaves

