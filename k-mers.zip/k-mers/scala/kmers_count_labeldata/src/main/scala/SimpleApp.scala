
/* SimpleApp.scala */
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object SimpleApp {
  def main(args: Array[String]) {
val conf = new SparkConf().setAppName("K-mers")
//conf.registerKryoClasses(Array(classOf[SimpleApp]))
conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
val sc = new SparkContext(conf)

val broadcastK = sc.broadcast(args(0).toInt)
//val broadcastN = sc.broadcast(N)

val textFile = sc.textFile(args(1))
val counts = textFile.flatMap(line => get_kmers(line.toString.split(",")(0), broadcastK.value)).map(word => (word, 1)).reduceByKey(_ + _)

import java.util.Calendar

counts.saveAsTextFile(args(2)+"/"+Calendar.getInstance().getTimeInMillis)
}

def get_kmers(line: String, k: Int): Array[String]={
 var kmers = Array[String]()
 val len = line.length()
 val conf = new SparkConf().setAppName("minorSC")
// val sc2 = new SparkContext(conf)

 def subs(string: String, x: Int, k: Int): String = {
      string.substring(x, x + k)
    }
 val subarr = Array.range(0, len-k+1)

// val broadcastK = sc2.broadcast(k)
// val broadcastLine = sc2.broadcast(line)

 return subarr.map(idx => subs(line, idx, k)).distinct
 }
}
