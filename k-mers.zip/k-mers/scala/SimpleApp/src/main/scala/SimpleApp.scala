
/* SimpleApp.scala */
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object SimpleApp {
  def main(args: Array[String]) {
val conf = new SparkConf().setAppName("K-mers")
val sc = new SparkContext(conf)
 
val textFile = sc.textFile(args(1))
val counts = textFile.flatMap(line => get_kmers(line.toString, args(0).toInt)).map(word => (word, 1)).reduceByKey(_ + _)
counts.saveAsTextFile(args(2))
}

def get_kmers(line: String, k: Int): Array[String]={
 //var line = input.toString
 var kmers = Array[String]()
 val len = line.length()
 for (i <- 0 to len-k){
	kmers = kmers:+line.slice(i,i+k)
 }
 return kmers.distinct
 }
}
