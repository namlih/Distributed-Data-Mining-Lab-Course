/* SimpleApp.scala */
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object SimpleApp {
  def substrings(string: String, k: Int): Seq[String] = {
    def subs(string: String, x: Int, k: Int): String = {
      string.substring(x, x + k)
    }
    val n: Int = string.length()
    val range = 0 to n - k
    range.map(index => subs(string, index, k)).distinct
  }

  def main(args: Array[String]): Unit = {
    val length: Int = args(0).toInt
    val conf = new SparkConf().setAppName("Substrings")
    val sc = new SparkContext(conf)
    val textFile = sc.textFile(args(1))
    val result = textFile.flatMap(line => substrings(line, length))
      .map(elem => (elem, 1))
     .reduceByKey(_ + _)
    result.saveAsTextFile(args(2))
  }
}
