spark-submit --master yarn --deploy-mode cluster --executor-memory 6g --driver-memory 6g --executor-cores 3 --num-executors 5 pyspark_k-mers.py
